#include <stdio.h>
#include <string.h>
#include "decode.h"
#include "common.h"

/* Validate decode arguments */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)  
{
    if (argv[2] == NULL)        
    {
        return e_failure;                               // no stego image provided
    }

    int len = strlen(argv[2]);                          // get length of filename

    if (len < 4 || strcmp(argv[2] + len - 4, ".bmp") != 0)
    {
        return e_failure;                               // check for .bmp extension
    }

    decInfo->stego_image_fname = argv[2];               // store stego image name

    if (argv[3] != NULL)
    {
        strcpy(decInfo->secret_fname, argv[3]);         // copy output filename
    }
    else
    {
        strcpy(decInfo->secret_fname, "output");        // default output name
    }

    return e_success;                                   // validation success
}

Status open_decode_files(DecodeInfo *decInfo)
{
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r"); // open stego image

    if (decInfo->fptr_stego_image == NULL)
        return e_failure;                               // file open failed

    return e_success;                                   // file open success
}

Status do_decoding(DecodeInfo *decInfo)
{
    if (open_decode_files(decInfo) == e_failure)
    {
        return e_failure;                               // open file failed
    }

    printf("FILES OPENED SUCCESSFULLY\n");

    fseek(decInfo->fptr_stego_image, 54, SEEK_SET);     // skip BMP header

    if (decode_magic_string(decInfo) == e_failure)
        return e_failure;                               // verify magic string

    if (decode_secret_file_extn_size(decInfo) == e_failure)
        return e_failure;                               // decode extension size
    printf("DECODED SECRET FILE EXTENTION SUCCESSFULLY\n");

    if (decode_secret_file_extn(decInfo) == e_failure)
        return e_failure;                               // decode extension
    printf("DECODED SECRET FILE EXTENTION SUCCESSFULLY\n");

    if (decode_secret_file_size(decInfo) == e_failure)
        return e_failure;                               // decode file size
    printf("DECODED SECRET FILE SIZE SUCCESSFULLY\n");

    if (decode_secret_file_data(decInfo) == e_failure)
        return e_failure;                               // decode file data
    printf("DECODED SECRET FILE DATA SUCCESSFULLY\n");

    fclose(decInfo->fptr_stego_image);                  // close stego image
    fclose(decInfo->fptr_secret);                       // close output file

    printf("DECODING COMPLETED SUCCESSFULLY\n");

    return e_success;                                   // decoding success
}

Status decode_magic_string(DecodeInfo *decInfo)
{
    char buffer[8];
    char decoded_char;
    char magic[10];

    for (int i = 0; i < strlen(MAGIC_STRING); i++)
    {
        fread(buffer, 8, 1, decInfo->fptr_stego_image); // read 8 bytes
        decode_byte_from_lsb(buffer, &decoded_char);    // extract character
        magic[i] = decoded_char;                        // store decoded char
    }

    magic[strlen(MAGIC_STRING)] = '\0';                 // terminate string

    if (strcmp(magic, MAGIC_STRING) != 0)
    {
        printf("ERROR: Magic string mismatch\n");       // validation failed
        return e_failure;
    }

    printf("DECODED MAGIC STRING SUCCESSFULLY\n");

    return e_success;                                   // success
}

Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    char buffer[32];

    fread(buffer, 32, 1, decInfo->fptr_stego_image);    // read 32 bytes
    decode_size_from_lsb(buffer, &decInfo->extn_size);  // extract extension size

    return e_success;
}

Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    char buffer[8];
    char decoded_char;
    char extn[20];

    for (int i = 0; i < decInfo->extn_size; i++)
    {
        fread(buffer, 8, 1, decInfo->fptr_stego_image); // read 8 bytes
        decode_byte_from_lsb(buffer, &decoded_char);    // decode character
        extn[i] = decoded_char;                         // store extension char
    }

    extn[decInfo->extn_size] = '\0';                    // terminate string

    if (strstr(decInfo->secret_fname, extn) == NULL)
    {
        strcat(decInfo->secret_fname, extn);            // append extension if missing
    }

    decInfo->fptr_secret = fopen(decInfo->secret_fname, "wb"); // open output file

    if (decInfo->fptr_secret == NULL)
        return e_failure;                               // file open failed

    return e_success;
}

Status decode_secret_file_size(DecodeInfo *decInfo)
{
    char buffer[32];

    fread(buffer, 32, 1, decInfo->fptr_stego_image);    // read 32 bytes
    decode_size_from_lsb(buffer, (int *)&decInfo->secret_file_size); // decode size

    return e_success;
}

Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char buffer[8];
    char decoded_char;

    for (long i = 0; i < decInfo->secret_file_size; i++)
    {
        fread(buffer, 8, 1, decInfo->fptr_stego_image); // read 8 bytes
        decode_byte_from_lsb(buffer, &decoded_char);    // decode byte
        fwrite(&decoded_char, 1, 1, decInfo->fptr_secret); // write to file
    }

    return e_success;
}

Status decode_byte_from_lsb(char *buffer, char *data)
{
    *data = 0;

    for (int i = 0; i < 8; i++)
    {
        *data = (*data << 1) | (buffer[i] & 1);          // extract each bit
    }

    return e_success;
}

Status decode_size_from_lsb(char *buffer, int *size)
{
    *size = 0;

    for (int i = 0; i < 32; i++)
    {
        *size = (*size << 1) | (buffer[i] & 1);          // reconstruct integer
    }

    return e_success;
}
