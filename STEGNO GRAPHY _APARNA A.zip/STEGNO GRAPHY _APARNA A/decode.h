#ifndef DECODE_H
#define DECODE_H

#include <stdio.h>
#include "types.h"

/* Structure for Decode */
typedef struct _DecodeInfo
{
    char *stego_image_fname;     // stores stego image file name
    FILE *fptr_stego_image;      // file pointer for stego image

    char secret_fname[100];      // output secret file name
    FILE *fptr_secret;           // file pointer for secret file

    int extn_size;               // size of file extension
    long secret_file_size;       // size of secret file data

} DecodeInfo;


/* Function Prototypes */

Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo); // validate decode arguments

Status open_decode_files(DecodeInfo *decInfo);                           // open stego image file

Status do_decoding(DecodeInfo *decInfo);                                 // main decoding function

Status decode_magic_string(DecodeInfo *decInfo);                         // decode and verify magic string
Status decode_secret_file_extn_size(DecodeInfo *decInfo);                // decode extension size
Status decode_secret_file_extn(DecodeInfo *decInfo);                     // decode extension and open output file
Status decode_secret_file_size(DecodeInfo *decInfo);                     // decode secret file size
Status decode_secret_file_data(DecodeInfo *decInfo);                     // decode secret file content

Status decode_byte_from_lsb(char *buffer, char *data);                   // extract 1 byte from 8 LSBs
Status decode_size_from_lsb(char *buffer, int *size);                    // extract 32-bit size from LSBs

#endif
