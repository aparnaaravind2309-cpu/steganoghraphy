#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"


/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

uint get_file_size(FILE *fptr)
{
    fseek(fptr, 0, SEEK_END);
    uint size = ftell(fptr);
    fseek(fptr, 0, SEEK_SET);
    return size;
    // Find the size of secret file data
}

/*
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    int len = strlen(argv[2]);

    if (len < 4 || strcmp(argv[2] + len - 4, ".bmp") != 0)   // validate source image (.bmp)
    {
        return e_failure;
    }
    encInfo->src_image_fname = argv[2];                       // store source image name

    char *dot = strchr(argv[3], '.');                         // check secret file extension
    if(dot == NULL || *(dot + 1) == '\0')
    {
        return e_failure;
    }
    encInfo->secret_fname = argv[3];                          // store secret file name

    if (argv[4] != NULL)                                      // check optional output file
    {
        len = strlen(argv[4]);
        if (len < 4 || strcmp(argv[4] + len - 4, ".bmp") != 0)
        {
            return e_failure;
        }
        encInfo->stego_image_fname = argv[4];                 // store output file name
    }
    else
    {
        encInfo->stego_image_fname = "stego.bmp";             // default output file
    }

    return e_success;
}

   

Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status check_capacity(EncodeInfo *encInfo)
{
    encInfo->image_capacity =
        get_image_size_for_bmp(encInfo->fptr_src_image);   // get total image capacity

    encInfo->size_secret_file =
        get_file_size(encInfo->fptr_secret);               // get secret file size

    int extn_size = 4;   // size of file extension (".txt")

    uint required_capacity =
        16 +                     // space for magic string (2 chars × 8 bits)
        32 +                     // space for extension size (32 bits)
        (extn_size * 8) +        // space for extension characters
        32 +                     // space for secret file size (32 bits)
        (encInfo->size_secret_file * 8);  // space for secret file data

    return (encInfo->image_capacity > required_capacity)   // check if image can hold data
           ? e_success : e_failure;                        // return status
}


Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char buffer[54];
    rewind(fptr_src_image);                              // move file pointer to beginning
    fread(buffer, 54, 1, fptr_src_image);                // read 54-byte BMP header
    fwrite(buffer, 54, 1, fptr_dest_image);              // write header to destination image
    return e_success;                                    // return success
}

Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    char buffer[8];

    for (int i = 0; magic_string[i] != '\0'; i++)         // loop through each character of magic string
    {
        fread(buffer, 8, 1, encInfo->fptr_src_image);     // read 8 bytes from source image
        encode_byte_to_lsb(magic_string[i], buffer);      // encode character into LSB
        fwrite(buffer, 8, 1, encInfo->fptr_stego_image);  // write modified data to stego image
    }
    return e_success;                                    // return success
}

Status encode_secret_file_extn_size(int size, EncodeInfo *encInfo)
{
    char buffer[32];
    fread(buffer, 32, 1, encInfo->fptr_src_image);        // read 32 bytes from source image
    encode_size_to_lsb(size, buffer);                     // encode extension size into LSB
    fwrite(buffer, 32, 1, encInfo->fptr_stego_image);     // write modified data to stego image
    return e_success;                                     // return success
}

Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    char buffer[8];

    for (int i = 0; file_extn[i] != '\0'; i++)             // loop through each character of extension
    {
        fread(buffer, 8, 1, encInfo->fptr_src_image);      // read 8 bytes from source image
        encode_byte_to_lsb(file_extn[i], buffer);          // encode each character into LSB
        fwrite(buffer, 8, 1, encInfo->fptr_stego_image);   // write modified data to stego image
    }
    return e_success;                                     // return success
}

Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    char buffer[32];
    fread(buffer, 32, 1, encInfo->fptr_src_image);        // read 32 bytes from source image
    encode_size_to_lsb(file_size, buffer);                // encode file size into LSB
    fwrite(buffer, 32, 1, encInfo->fptr_stego_image);     // write modified data to stego image
    return e_success;                                     // return success
}




Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char data;
    char buffer[8];

    while (fread(&data, 1, 1, encInfo->fptr_secret) == 1)   // read 1 byte from secret file
    {
        fread(buffer, 8, 1, encInfo->fptr_src_image);       // read 8 bytes from source image
        encode_byte_to_lsb(data, buffer);                   // encode 1 byte into 8 bytes (LSB)
        fwrite(buffer, 8, 1, encInfo->fptr_stego_image);    // write modified data to stego image
    }
    return e_success;                                       // return success
}


Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch;
    while (fread(&ch, 1, 1, fptr_src) == 1)   // read byte from source until EOF
    {
        fwrite(&ch, 1, 1, fptr_dest);         // write byte to destination
    }
    return e_success;                         // return success
}

Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for (int i = 0; i < 8; i++)              // loop through 8 bits of data
    {
        image_buffer[i] =                   // modify LSB of each byte
            (image_buffer[i] & 0xFE) |     // clear LSB
            ((data >> (7 - i)) & 1);       // set LSB with data bit
    }
    return e_success;                      // return success
}


Status encode_size_to_lsb(int size, char *imageBuffer)
{
    for (int i = 0; i < 32; i++)          // loop through 32 bits of size
    {
        imageBuffer[i] =                 // modify LSB of each byte
            (imageBuffer[i] & 0xFE) |   // clear LSB
            ((size >> (31 - i)) & 1);   // set LSB with size bit
    }
    return e_success;                   // return success
}

Status do_encoding(EncodeInfo *encInfo)
{
    if (open_files(encInfo) == e_failure)              // open required files
    {
        printf("FILE OPENING NOT SUCCESSFUL\n");
        return e_failure;
    }
    printf("FILE OPENING SUCCESSFUL\n");

    if (check_capacity(encInfo) == e_failure)          // check image capacity
    {
        printf("ERROR: Insufficient image capacity\n");
        return e_failure;
    }
    printf("IMAGE CAPACITY VALIDATED\n");

    if (copy_bmp_header(encInfo->fptr_src_image,
                        encInfo->fptr_stego_image) == e_failure)   // copy BMP header
    {
        printf("ERROR: Failed to copy BMP header\n");
        return e_failure;
    }
    printf("BMP HEADER COPIED SUCCESSFULLY\n");

    if (encode_magic_string(MAGIC_STRING, encInfo) == e_failure)   // encode magic string
    {
        printf("ERROR: Failed to encode magic string\n");
        return e_failure;
    }
    printf("ENCODED MAGIC STRING SUCCESSFULLY\n");

    char *extn = strchr(encInfo->secret_fname, '.');   // extract file extension

    if (encode_secret_file_extn_size(strlen(extn), encInfo) == e_failure)   // encode extension size
    {
        printf("ERROR: Failed to encode extension size\n");
        return e_failure;
    }
    printf("ENCODED FILE EXTENSION SIZE SUCCESSFULLY\n");

    if (encode_secret_file_extn(extn, encInfo) == e_failure)   // encode extension
    {
        printf("ERROR: Failed to encode extension\n");
        return e_failure;
    }
    printf("ENCODED SECRET FILE EXTENSION SUCCESSFULLY\n");

    if (encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_failure)  // encode file size
    {
        printf("ERROR: Failed to encode secret file size\n");
        return e_failure;
    }
    printf("ENCODED SECRET FILE SIZE SUCCESSFULLY\n");

    if (encode_secret_file_data(encInfo) == e_failure)   // encode file data
    {
        printf("ERROR: Failed to encode secret data\n");
        return e_failure;
    }
    printf("ENCODED SECRET FILE DATA SUCCESSFULLY\n");

    if (copy_remaining_img_data(encInfo->fptr_src_image,
                                encInfo->fptr_stego_image) == e_failure)   // copy remaining data
    {
        printf("ERROR: Failed to copy remaining image data\n");
        return e_failure;
    }

    fclose(encInfo->fptr_src_image);   // close all files
    fclose(encInfo->fptr_secret);
    fclose(encInfo->fptr_stego_image);

    printf("ENCODING COMPLETED SUCCESSFULLY\n");

    return e_success;
}
