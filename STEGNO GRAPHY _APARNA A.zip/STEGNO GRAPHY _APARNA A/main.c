/*APARNA A 
16-02-2026
PROJECT NAME:STEGNOGRAPHY
PROJECT DESCRIPTION: Steganography is a technique used to hide secret data inside an image without visibly changing the image.
SAMPLE INPUT: namma bengaluru hello world
SMAPLE OUTPUT:namma bengaluru hello world
              Encode operation
FILE OPENING SUCCESSFUL
width = 1024
height = 768
IMAGE CAPACITY VALIDATED
BMP HEADER COPIED SUCCESSFULLY
ENCODED MAGIC STRING SUCCESSFULLY
ENCODED FILE EXTENSION SIZE SUCCESSFULLY
ENCODED SECRET FILE EXTENSION SUCCESSFULLY
ENCODED SECRET FILE SIZE SUCCESSFULLY
ENCODED SECRET FILE DATA SUCCESSFULLY
ENCODING COMPLETED SUCCESSFULLY
ENCODING SUCCESS

Decode operation
FILES OPENED SUCCESSFULLY
DECODED MAGIC STRING SUCCESSFULLY
DECODED SECRET FILE EXTENTION SUCCESSFULLY
DECODED SECRET FILE EXTENTION SUCCESSFULLY
DECODED SECRET FILE SIZE SUCCESSFULLY
DECODED SECRET FILE DATA SUCCESSFULLY
DECODING COMPLETED SUCCESSFULLY
DECODE SUCCESS
              */
#include <stdio.h>
#include<string.h>
#include "encode.h"
#include "types.h"
#include "decode.h"

OperationType check_operation_type(char *);

int main(int argc, char *argv[])
{
   if(argc < 2)                                      // check minimum arguments
   {
      printf("Invalid arguments\n");
      return e_failure;
   }

   OperationType op_type = check_operation_type(argv[1]);   // identify operation type (-e / -d)

   /*...................Encoding.................*/   
   if  (op_type == e_encode)                         // check if encoding operation
   {
      if (argc < 4)                                  // validate encoding arguments
      {
         printf("ERROR: invalid arguments for encoding\n");
         return e_failure;
      }

      printf("Encode operation\n");                  // print encode operation
      EncodeInfo encInfo;                            // declare EncodeInfo structure

      if(read_and_validate_encode_args(argv, &encInfo) == e_success)   // validate encode args
      {
         if (do_encoding(&encInfo) == e_success)     // perform encoding
         {
             printf("ENCODING SUCCESS\n");           // success message
         }
         else
         {
             printf("ERROR: Encoding failed\n");     // encoding failed
         } 
      }
      else
      {
         printf("ERROR: validation failed for encoding\n");   // validation failed
      }
   }

   /*...................Decoding.................*/
   else if (op_type == e_decode)                     // check if decoding operation
   {
      if (argc < 3)                                  // validate decoding arguments
      {
         printf("ERROR: Invalid arguments for decoding\n");
         return e_failure;
      }

      printf("Decode operation\n");                  // print decode operation
      DecodeInfo decInfo;                            // declare DecodeInfo structure

      if (read_and_validate_decode_args(argv, &decInfo) == e_success)  // validate decode args
      {
         if (do_decoding(&decInfo) == e_success)     // perform decoding
         {
               printf("DECODE SUCCESS\n");           // success message
         }
         else
         {
               printf("ERROR: Decoding failed\n");   // decoding failed
         }
      }
      else
      {
         printf("ERROR: Validation failed for decoding\n");   // validation failed
      }
   }
   else
   {
      printf("ERROR: Unsupported operation\n");      // invalid option
   }
}

OperationType check_operation_type(char *symbol)   // check it is -e or -d 
{
    if (strcmp(symbol, "-e") == 0)                  // if "-e" return encode
       return e_encode;
    else if (strcmp(symbol, "-d") == 0)             // if "-d" return decode
       return e_decode;
    else 
       return e_unsupported;                        // else unsupported
}

    


